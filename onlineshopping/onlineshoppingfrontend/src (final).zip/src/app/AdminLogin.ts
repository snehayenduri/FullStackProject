export class AdminLogin{
    adminId: number;
    adminName: string;
    password: string;
}