import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-retailer-footer',
  templateUrl: './retailer-footer.component.html',
  styleUrls: ['./retailer-footer.component.css']
})
export class RetailerFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
