export class Retailer{
    retailerId : number=0;
    retailerName : string="";
    emailId : string="";
    mobileNumber : number=0;
    password : string="";
    adminId : number=1;
}