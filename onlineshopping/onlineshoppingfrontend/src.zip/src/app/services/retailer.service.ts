import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Category } from '../customer/Category';
import { Products } from '../customer/Products';
import { Retailer } from '../Retailer';

@Injectable({
  providedIn: 'root'
})
export class RetailerService {

  private baseUrl = "http://localhost:8084/retailer";

  constructor(private http : HttpClient) { }

  login(retailerId:number){
    console.log(retailerId);

    console.log("In services : "+ (this.http.get<Retailer>(this.baseUrl+"/getRetailer/"+retailerId)));
    return this.http.get<Retailer>(this.baseUrl+"/getRetailer/"+retailerId);
  }

  getCategory(categoryId:number)
  {
    console.log(categoryId);

    console.log("In services : "+ (this.http.get<Category>(this.baseUrl+"/getCategory/"+categoryId)));
    return this.http.get<Category>(this.baseUrl+"/getCategory/"+categoryId);
  }
  addProduct(product :Products){
    console.log('In service');
       return this.http.post(this.baseUrl+"/addRetailerProduct",
         JSON.stringify(product),
       {
          headers:
             { 'Content-Type': 'application/json' }
        });
  }

  showMyProducts(retailerId:number){
    console.log('In service' + this.http.get<Products[]>(this.baseUrl+"/getRetailerProductsById/"+retailerId));
    return this.http.get<Products[]>(this.baseUrl+"/getRetailerProductsById/"+retailerId);
  }

  updateProduct(product : Products){
    console.log('In service');
      return this.http.post<Products>(this.baseUrl+"/updateProduct",
        JSON.stringify(product),
        {
          headers:
            { 'Content-Type': 'application/json' }
        });
  }

  getProductById(productId : number):Observable<Products>{
    console.log('In service');
    console.log(productId);
    console.log(this.http.get<Products>("http://localhost:8084/customer/products/"+productId));
    return this.http.get<Products>("http://localhost:8084/customer/products/"+productId);
  }

  deleteProduct(productId : number){
    console.log('In service');
    return this.http.delete<Products>(this.baseUrl+"/deleteProduct/"+productId);
  }
}
