import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/services/customer.service';
import { Products } from '../Products';

@Component({
  selector: 'app-customer-productsearch',
  templateUrl: './customer-productsearch.component.html',
  styleUrls: ['./customer-productsearch.component.css']
})
export class CustomerProductsearchComponent implements OnInit {

  productDetail !:Products;
  productName="";
  msg:string="";
  userId:string;

  constructor(private productService: CustomerService) { }

  ngOnInit(): void {
    this.onSearch();
  }

  onSearch(){
    this.productService.getProductByName(this.productName).subscribe(
      response=>{this.productDetail=response}
    )
  }

  addToMyCart(productID: number) {
    let cId=Number(localStorage.getItem('customerId'))
    this.productService.addToMyCart(cId, productID).subscribe((data: string) => {
    this.msg=data;
    console.log(this.msg);
    console.log(this.userId)
    console.log(productID)
    });
  }

}
