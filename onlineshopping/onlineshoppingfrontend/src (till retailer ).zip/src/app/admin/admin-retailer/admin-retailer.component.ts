import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-retailer',
  templateUrl: './admin-retailer.component.html',
  styleUrls: ['./admin-retailer.component.css']
})
export class AdminRetailerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
