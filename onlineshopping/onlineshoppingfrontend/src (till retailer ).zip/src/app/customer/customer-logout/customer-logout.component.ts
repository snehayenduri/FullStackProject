import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-logout',
  templateUrl: './customer-logout.component.html',
  styleUrls: ['./customer-logout.component.css']
})
export class CustomerLogoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
