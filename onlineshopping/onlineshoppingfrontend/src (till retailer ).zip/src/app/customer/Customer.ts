export class Customer{
    customerId : number=0;
    customerName : string="";
    password : string="";
    doorNo: string="";
    street: string="";
    city: string="";
    state: string="";
    country: string="";
    pincode: number=0;
    mobileNumber:number=0;
    emailAddres:string=""; 
}