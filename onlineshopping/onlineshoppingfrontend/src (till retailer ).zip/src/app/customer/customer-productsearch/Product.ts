export class Product{
    productId:number=0;
    productName:string="";
    productCost:number=0;
    productImage:string="";
    productBrand:string="";
    quantity:number=0;
}